import java.awt.*;
import java.awt.event.*;

public class FechandoJanela extends WindowAdapter
{
  public void windowClosing( WindowEvent e) 
  {
    System.exit (0);
  }
}
